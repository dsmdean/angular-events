'use strict';

eventsApp.controller('EditEventController',
    function EditEventController($scope, eventData) {
        
        $scope.saveEvent = function(event, newEventForm) {
            if(newEventForm.$valid) {
                eventData.save(event)
                    .$promise
                    .then(
                        function(response) {
                            console.log('success', response);
                        }
                        
                    )
                    .catch(
                        function(response) {
                            console.log('failiure', response);
                        }
                    );
            }
        };

        $scope.cancelEdit = function() {
            window.location = "/EventDetails.html";
        };
    }
);