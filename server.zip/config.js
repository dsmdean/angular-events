module.exports = {
    'secretKey': '12345-67890-09876-54321',
    'mongoUrl': 'mongodb://localhost:27017/angularEvents',
    'facebook': {
        clientID: 1773571869545862,
        clientSecret: '6d93801ec0e93c4bb0ef2978f93928e0',
        callbackURL: 'http://localhost:3000/users/facebook/callback'
    }
}